#ifndef _NC_EXTEND_H_
#define _NC_EXTEND_H_


#include <nc_conf.h>


rstatus_t conf_get_server_hash_range(struct conf_server **field,uint32_t addrlen,char *addr );


#endif
