#include <nc_extend.h>

rstatus_t conf_get_server_hash_range(struct conf_server **field,uint32_t addrlen,char *addr )
{
    int begin =0;
    int end = 0;
    int i;
    int j;
    for(i=0;i<addrlen;i++)
    {
        if( ':' == (char)addr[i] )
        {
            begin = i;
            break;
        }
    }
    int len = strlen( (char*)addr );
    for(i=begin+1;i<len;i++)
    {
        if( ':' == (char)addr[i] )
        {
            end = i;
            break;
        }
    }
    uint8_t *tmp = (uint8_t*)malloc((end-begin+1));
    memset( tmp, 0,(end-begin) );
    j=0;
    for( i=begin+1;i<end;i++)
    {
        tmp[j] = addr[i];
        j++;
    }
    char beginStr[1024];
    char endStr[1024];
    memset( beginStr,0,1024);
    memset( endStr,0,1024);
    i=0;
    int pos =0;
    for(;i<strlen(tmp);i++)
    {
        if( '/' == tmp[i] )
        {
            pos =i;
            break;
        }
        beginStr[i] = tmp[i];
    }
    j=0;
    for(i=pos+1;i<strlen(tmp);i++)
    {
        endStr[j++] = tmp[i];
    }
    (*field)->rangebegin=atoi(beginStr);
    (*field)->rangeend=atoi(endStr);
    return 0;
}
