#ifndef __NC_TEST_H__
#define __NC_TEST_H__
int test();
#endif
