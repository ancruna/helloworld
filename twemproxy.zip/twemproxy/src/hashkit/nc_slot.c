/*
 * add by miaolinjie
 */


#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <nc_core.h>
#include <nc_server.h>
#include <nc_hashkit.h>

static int
slot_item_cmp(const void* t1, const void* t2)
{
    const struct continuum *ct1 = t1, *ct2 = t2;
    if( ct1->rangebegin == ct2->rangebegin )
    {
        return 0;
    }
    else if( ct1->rangebegin > ct2->rangebegin )
    {
        return 1;
    }
    else
    {
        return -1;
    }
}
rstatus_t checkRange( struct server_pool *pool, uint32_t low, uint32_t high, uint32_t nserver )
{
    uint32_t i = 0;
    for( ; i< nserver-1; i++ )
    {
        if(pool->continuum1[i].rangeend != pool->continuum1[i+1].rangebegin-1)
        {
            log_error( "configure error, number [%d] rangeend is [%d], number+1 [%d] rangebegin is [%d], please make sure a=b-1!",i,pool->continuum1[i].rangeend,i+1,pool->continuum1[i+1].rangebegin);
            return NC_ERROR;
        } 
    }
    if( pool->continuum1[0].rangebegin != low )
    {
        log_error("configure error, please make lowest[%d] equal to [%d]",pool->continuum1[0].rangebegin,low);
        return NC_ERROR;
    }
    if( pool->continuum1[nserver-1].rangeend != high )
    {
        log_error("congfigure error, please make highest[%d] equal to [%d]",pool->continuum1[nserver-1].rangeend,high);
        return NC_ERROR;
    }
    return NC_OK;
}

rstatus_t
slot_update( struct server_pool *pool )
{
    uint32_t nserver;//server的数目
    uint32_t continuum_index;
    uint32_t server_index;
    int64_t now;// 当前时间
    rstatus_t status;
    ASSERT( array_n( &pool->server) > 0 );
    nserver = array_n( &pool->server );//当前server个数
    pool->nlive_server = nserver;// 简化计算
    struct continuum *continuum;
    continuum = nc_realloc(pool->continuum1, sizeof(*continuum)*nserver);
    if( NULL == continuum )
    {
        return NC_ENOMEM;
    }
    pool->continuum1 = continuum;
    continuum_index = 0;
    for( server_index = 0; server_index < nserver; server_index++)
    {
        struct server *serverTmp = array_get(&pool->server, server_index );
        pool->continuum1[continuum_index].index = server_index;
        pool->continuum1[continuum_index].rangebegin = serverTmp->rangebegin;
        pool->continuum1[continuum_index++].rangeend = serverTmp->rangeend;
    }
    qsort(pool->continuum1, nserver, sizeof(*pool->continuum1), slot_item_cmp);
    status = checkRange(pool,NC_CONF_RANGE_BEGIN,NC_CONF_RANGE_END,nserver); 
    if( status != NC_OK )
    {
        return NC_ERROR;
    }
    return NC_OK;
}
uint32_t slot_dispatch( struct continuum *continuum, uint32_t ncontinuum, uint32_t hash )
{
    struct continuum *begin, *end, *left, *right, *middle;
    ASSERT( continuum != NULL );
    ASSERT( ncontinuum != 0 );
    begin = left = continuum;
    end = right = continuum + ncontinuum;
    while( left < right )
    {
        middle = left + (right-left) / 2;
        if( middle->rangebegin < hash )
        {
            left = middle + 1;
        }
        else
        {
            right = middle;
        }
    }
    if( right == end )
    {
        right = begin;
    }
    return right->index;
}



