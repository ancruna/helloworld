#include "nc_test.h"

int test()
{return 0;}
