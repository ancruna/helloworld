act=$1

if [ "$act" == "--help" ]
then
    echo "please run the script like [[ sh control.sh <start|stop|restart> ]]"
    exit
fi

if [ "$act" == "restart" ]
then
    pid=$(ps -fe|grep "bin/nutcracker"|grep -v "grep"|awk -F " " '{ print $2 }')
    kill -9 ${pid}
    nohup ./bin/nutcracker -d -c conf/nutcracker.yml -p run/redisproxy.pid -o logs/redisproxy.log -s 22223 &
    exit
fi

if [ "$act" == "start" ]
then
    nohup ./bin/nutcracker -d -c conf/nutcracker.yml -p run/redisproxy.pid -o logs/redisproxy.log -s 22223 &
    exit
fi

if [ "$act" == "stop" ]
then
    pid=$(ps -fe|grep "bin/nutcracker"|grep -v "grep"|awk -F " " '{ print $2 }')
    kill -9 ${pid}
    exit
fi
