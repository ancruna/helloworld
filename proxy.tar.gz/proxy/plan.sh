act=$1
bmc="hk01-img-i18n-tn02.hk01.baidu.com"
server_path="/home/gredis/redis_service/proxy8901/proxy"
ac="gredis"

if [ "$act" == "--help" ]
then
    echo "the script can run ya|online ..."
    exit
fi

if [ "$act" == "ya" ]
then
    cd ${server_path}
    cp conf/nutcracker.yml_ya conf/nutcracker.yml
    sh control.sh restart
    ssh ${ac}@${bmc} cd ${server_path} ";" cp conf/nutcracker.yml_ya conf/nutcracker.yml ";" sh control.sh restart
fi

if [ "$act" == "online" ]
then
    cd ${server_path}
    cp conf/nutcracker.yml_online conf/nutcracker.yml
    sh control.sh restart
    ssh ${ac}@${bmc} cd ${server_path} ";" cp conf/nutcracker.yml_online conf/nutcracker.yml ";" sh control.sh restart
fi
