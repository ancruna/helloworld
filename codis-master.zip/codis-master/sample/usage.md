0. start zookeeper 
1. change config items in config.ini 
2. ./start_dashboard.sh 
3. ./start_redis.sh 
4. ./add_group.sh 
5. ./initslot.sh 
6. ./start_proxy.sh 
7. ./set_proxy_online.sh 
8. open browser to http://localhost:18087/admin 

