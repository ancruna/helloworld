// Copyright 2014 Wandoujia Inc. All Rights Reserved.
// Licensed under the MIT (MIT-LICENSE.txt) license.

package models

const (
	INVALID_ID = -1
)

const (
	DEFAULT_SLOT_NUM = 1024
)
