#!/usr/bin/env python
import os,sys
import json
import yaml
import commands
from redis.sentinel import Sentinel
from datetime import *
import time
import logging

if __name__ == '__main__':
    while 1:
        sl=Sentinel([("10.46.139.48","26761")],socket_timeout=1)
        sentinel_master=sl.discover_master("c1")
        time.sleep(0.5)
        print sentinel_master

